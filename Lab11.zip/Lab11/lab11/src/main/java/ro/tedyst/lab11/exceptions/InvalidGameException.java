package ro.tedyst.lab11.exceptions;

public class InvalidGameException extends Exception {
    public InvalidGameException(String message) {
        super(message);
    }
}
